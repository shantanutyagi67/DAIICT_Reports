from pykrige.ok import OrdinaryKriging
import numpy as np

gridx = np.linspace(68,74.9,300)
gridy = np.linspace(20,24.9,300)

# The first member of each sub-array is longitude,
# second member is latitude,
# and the third member is CO2 level at that place
data = np.array([[70.5, 21., 399.3261414],
                 [70.5, 23., 400.331604],
                 [73.5, 21., 400.6151123],
                 [73.5, 23., 402.4023438]])

OK = OrdinaryKriging(data[:, 0], data[:, 1], data[:, 2], variogram_model='gaussian',
                     verbose=False, enable_plotting=False)

z, ss = OK.execute('grid', gridx, gridy)

co2_kriged = np.zeros((300*300,3))

k = 0
for i in range(0,300):
    for j in range(0,300):
        co2_kriged[k,0] = gridx[i]
        co2_kriged[k,1] = gridy[j]
        co2_kriged[k,2] = z[j,i]
        k = k + 1

np.savetxt("co2_kriged.csv", co2_kriged, delimiter=",")

