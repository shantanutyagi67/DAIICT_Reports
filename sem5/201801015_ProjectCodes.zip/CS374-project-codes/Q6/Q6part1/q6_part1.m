clear;
clc;
close all;
format long;
syms fun(x,y) f(x,y) t(x)
fun(x,y)= (x-y)/(x+y);
end_val=1;
t(x)= sqrt((2*x^2+1))-x;
n=100;

%Runge Kutta 4
[x1,y1]=rk4(0,t(0),fun,n,0.01);
y_rk4= y1;
y_err_rk4= abs(t(x1)-y1);
xn=x1;
plot(xn,y_rk4,'ko');
grid on
hold on



%Runge Kutta 2
[x1,y1]=rk2(0,t(0),fun,n,0.01);
y_rk2= y1;
y_err_rk2= abs(t(x1)-y1);
xn=x1;
plot(xn,y_rk2,'r*');
grid on
hold on

%Euler method
[x1,y1]=euler_2(0,t(0),fun,n,0.01);
y_euler= y1;
y_err_euler= abs(t(x1)-y1);
xn=x1;
plot(xn,y_euler,'y+');
grid on
hold on

xe=x1;
xr=linspace(-1,1,200);
yn=t(xr);
plot(xr,yn,'b.-');
xlim([0 1])
grid on
hold on
 
legend({'RungeKutta4 Method','RungeKutta2 Method','Euler Method','Actual function'},'Location','northeast')
xlabel('X')
ylabel('Y')
% xlim([-1.2 1.2])
% ylim([-1.2 1.2])
title('Calculated Values');

%%
figure(2)
%error plot
plot(xn,y_err_rk4,'r*')
grid on
hold on
plot(xn,y_err_rk2,'yo')
grid on
hold on
plot(xn,y_err_euler,'b.')
grid on
hold on
legend({'Runge Kutta(4) Method','Runge Kutta(2) Method','Euler Method'},'Location','northwest')
xlabel('X')
ylabel('Absolute Error')
xlim([0 1])
title('Error Plot');
