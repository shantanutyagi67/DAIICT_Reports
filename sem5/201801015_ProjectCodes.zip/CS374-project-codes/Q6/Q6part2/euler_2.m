function [x1,y1] = euler_2(x0,y0,f,n,h)
    %h=0.01;%step size
    y1=zeros(1,n);
    i=1;
    y1(i)=y0;
    x1(i)=x0;
    
    while i<=n
        x0=x1(i);
        y0=y1(i);
        i=i+1;
        y1(i)=y0+h*f(x0,y0);
        x1(i)=x0+h;         
    end
end