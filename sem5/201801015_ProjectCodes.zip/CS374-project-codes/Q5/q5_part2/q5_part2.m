%%
clear all;
close all;
format long;
dx = 0.001;
fun = @(x) 1./(1+sinh(2*x).*log(x).*log(x));
figure (1);
fplot(fun)
title('Function Plot')
xlabel('X value')
ylabel('Y value')
grid on;
    
%%
% vary limit and check error
err_rect=[];
err_simp=[];
err_trap=[];
err_mid=[];
err_gauss=[];
for i=0.5:0.5:10
    x = linspace(1e-6,i,100+(i-0.5)*200);
    x1=1e-6:dx:i;
    y=double(1./(1+sinh(2*x).*log(x).*log(x)));
    y1=double(1./(1+sinh(2*x1).*log(x1).*log(x1)));
    y2=double(1./(1+sinh(2*(x1+dx/2)).*log((x1+dx/2)).*log((x1+dx/2))));
    q = integral(fun,1e-6,i);
    S1 = trapz(x,double(y));
    S2 = sum(y1*dx);
    S3 =  SIMP(x,y);
    S4 = sum(y2*dx);
    S5= gauss2Point(1e-6, i, dx, fun);
    err_rect(end+1)=abs(S2-q);
    err_simp(end+1)=abs(S3-q);
    err_trap(end+1)=abs(S1-q);
    err_mid(end+1)=abs(S4-q);
    err_gauss(end+1)=abs(S5-q);
end
x_axis=0.5:0.5:10;
figure(2);
plot(x_axis,err_rect,'r-*')
hold on;
% title('Error Plot for Rectangular Method')
% grid on;
% figure(3);
plot(x_axis,err_simp,'g-*')
grid on;
title('Error Plot ')
hold on;
plot(x_axis,err_trap,'b-*')
hold on;
plot(x_axis,err_mid,'y-*')
hold on;
plot(x_axis,err_gauss,'k-*')
xlabel('Upper limit of integration')
ylabel('Absolute error')
legend({'Rectangular Method','Trapezium Method','Simpsons Method','Midpoint Method','Gauss Two Point Method'},'Location','northeastoutside')
%%
% plot final values
% function of x where ans is integral of 0 to x for expr
final_plot=[];
final_plot_rect=[];
final_plot_simp=[];
final_plot_trap=[];
final_plot_mid=[];
final_plot_gauss=[];
for i=0.5:0.5:50
    x = linspace(1e-6,i,100+(i-0.5)*200);
    x1=1e-6:dx:i;
    y=double(1./(1+sinh(2*x).*log(x).*log(x)));
    y1=double(1./(1+sinh(2*x1).*log(x1).*log(x1)));
    y2=double(1./(1+sinh(2*(x1+dx/2)).*log((x1+dx/2)).*log((x1+dx/2))));
    final_plot(end+1)= integral(fun,0,i);
    final_plot_trap(end+1) = trapz(x,double(y));
    final_plot_rect(end+1) = sum(y1*dx);
    final_plot_simp(end+1) =  SIMP(x,y); 
    final_plot_mid(end+1) =  sum(y2*dx);
    final_plot_gauss(end+1) =  gauss2Point(1e-6, i, dx, fun);
end
x_axis=0.5:0.5:50;
figure(4);
plot(x_axis,final_plot,'r-')
title('Net Integral plots')
grid on;
hold on;
plot(x_axis,final_plot_rect,'p-')
grid on;
hold on;
plot(x_axis,final_plot_simp,'g-')
grid on;
hold on;
plot(x_axis,final_plot_trap,'b-')
hold on;
plot(x_axis,final_plot_mid,'y-')
hold on;
plot(x_axis,final_plot_gauss,'k-')
xlabel('Upper limit of integration')
ylabel('Integral Value')
legend({'Actual Plot','Rectangular Method','Trapezium Method','Simpsons Method','Midpoint Method','Gauss Two Point Method'},'Location','northeastoutside')




