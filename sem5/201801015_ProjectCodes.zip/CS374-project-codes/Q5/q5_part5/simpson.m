function z = simpson(a,b,n,f)
    z=0;
    h = (b-a)/n;
    for i=1:n-1
        if rem(i,2)==1
            z=z+f(a+i*h)*4;
        else
            z=z+f(a+i*h)*2;%sum of odd terms
        end
    end
    
    z=z+f(a)+f(b);
    z=z*h/3;
end